<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Traits\ApiResponse;
use App\Http\Requests\StoreDokumenRequest;
use App\Models\Dokumen;
use App\Models\SimRegister;
use App\Services\FileUploadService;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class DokumenController extends Controller
{
    use ApiResponse;

    public function index()
    {
        try {

            $dokumens = Dokumen::query();
            if (!is_null(request('register'))) {
                $dokumens->where('dokumens.register', request('register'));
            }

            return $this->okApiResponse(
                $dokumens->get(),
                'Berhasil Memuat Data'
            );
        } catch (\Throwable $th) {

            return $this->errorApiResponse([
                'msg' => $th->getMessage(),
                'trace' => $th->getTraceAsString()
            ]);
        }
    }

    public function data()
    {
        try {

            $dokumens = Dokumen::all();

            return $this->okApiResponse(
                $dokumens,
                'Berhasil Memuat Data'
            );
        } catch (\Throwable $th) {

            return $this->errorApiResponse([
                'msg' => $th->getMessage(),
                'trace' => $th->getTraceAsString()
            ]);
        }
    }

    public function store(StoreDokumenRequest $request)
    {
        try {

            DB::beginTransaction();

            $pasien = SimRegister::with('pasien')
                ->where('REGISTER', $request->register)
                ->first();

            if (is_null($pasien)) {
                throw new ModelNotFoundException('Pasien tidak ditemukan');
            }

            $fileRequest = $request->validated();

            $fileRequest = array_merge($fileRequest, [
                'register' => $pasien->REGISTER,
                'created_by' => 1,
                'created_by_name' => 'Salman',
                'tgl_mrs' => $pasien->TANGGAL,
                'mr' => $pasien->MR,
                'nama' => $pasien->pasien->NAMA,
                'tgl_lahir' => $pasien->pasien->TGL_LAHIR,
            ]);

            $check = Dokumen::where(['register' => $pasien->REGISTER, 'nama_dok' => $request->nama_dok])->first();

            if (!is_null($check)) {
                throw new \Exception('File sudah ada');
            }
            $dokumen = Dokumen::create($fileRequest);

            /**
             * UPLOAD FILE
             */
            $result = null;

            if ($request->hasFile('files')) {

                $files = $request->file('files');
                $uploadService = new FileUploadService();
                $filesPayload = [];
                $rules = ['file' => ['required', 'image', 'max:2048']];
                foreach ($files as $key => $file) {

                    /**
                     * Validation Image
                     */
                    $validator = Validator::make(['file' => $file], $rules);
                    if ($validator->passes()) {

                        $tglPeriksaRule = str_replace('-', '_', $request->tgl_periksa);

                        $nameRule = str_replace(' ', '_', $request->nama_dok);

                        $penunjang = $request->penunjang;

                        $filename = ++$key . '_' . $pasien->MR . '_' . $nameRule . '_' . $tglPeriksaRule . '_' . $penunjang . '.' . $file->getClientOriginalExtension();

                        $uploadService->setFile($file);
                        $uploadService->setFilename($filename);
                        $uploadService->setDisk('public');
                        $uploadService->setPath('berkas/' . $pasien->MR . '/' . $pasien->REGISTER);
                        $uploadService->setExtension($file->getClientOriginalExtension());
                        $data = $uploadService->upload($request, $pasien, $request->user());
                        $data['id_file'] = $dokumen->id;
                        array_push($filesPayload, $data);
                    }
                    if ($validator->fails()) {
                        throw new \Exception($validator->errors());
                    }

                }

                if (count($filesPayload) > 0) {
                    $result = $uploadService->insertDB($filesPayload);
                } else {
                    throw new \Exception();
                }
            } else {
                throw new \Exception(gettype($request->hasFiles('files')));
            }

            DB::commit();

            return $this->createdApiResponse($result, 'Berhasil ditambahkan');
        } catch (\Throwable $th) {
            DB::rollBack();

            return $this->errorApiResponse([
                'msg' => $th->getMessage(),
                'trace' => $th->getTraceAsString()
            ]);
        }
    }

    public function show($id)
    {
        try {
            $dokumens = Dokumen::find($id);

            return $this->okApiResponse($dokumens, 'Berhasil diupdate');
        } catch (\Throwable $th) {

            return $this->errorApiResponse([
                'msg' => $th->getMessage(),
                'trace' => $th->getTraceAsString()
            ]);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $data = $request->all();

            $dokumens = Dokumen::find($id);
            $dokumens->update($data);

            return $this->okApiResponse($data, 'Berhasil diubah');
        } catch (\Throwable $th) {

            return $this->errorApiResponse([
                'msg' => $th->getMessage(),
                'trace' => $th->getTraceAsString()
            ]);
        }
    }

    public function destroy($id)
    {
        try {
            $dokumens = Dokumen::find($id);
            $dokumens->delete();

            return $this->noContentApiResponse('Berhasil dihapus');
        } catch (\Throwable $th) {

            return $this->errorApiResponse([
                'msg' => $th->getMessage(),
                'trace' => $th->getTraceAsString()
            ]);
        }
    }

    public function registerByRm($mr)
    {
        try {

            $dir = Dokumen::select('register')
                ->getRegistByNoRm($mr)
                ->get();

            return $this->okApiResponse($dir, 'Berhasil dimuat');
        } catch (\Throwable $th) {

            return $this->errorApiResponse([
                'msg' => $th->getMessage(),
                'trace' => $th->getTraceAsString()
            ]);
        }
    }
}
